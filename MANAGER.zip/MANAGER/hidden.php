<?php
$dbname="imionafresh";
$host="localhost";
$user="root";
$passwd="";
?>