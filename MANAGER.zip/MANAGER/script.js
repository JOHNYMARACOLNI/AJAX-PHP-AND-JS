function send() {
    const imie = encodeURIComponent(document.getElementById("imie").value);

    fetch("ajax.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `acc=add&imie=${imie}`,
    })
        .then(response => {
            if (response.ok) {
                get(); // Po udanym dodaniu, pobierz nowe dane
            } else {
                console.error("Błąd podczas wysyłania danych");
            }
        })
        .catch(error => {
            console.error("Błąd sieciowy:", error);
        });
}

function get() {
    fetch("ajax.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "acc=get",
    })
        .then(response => {
            if (response.ok) {
                return response.json(); // Parsuj odpowiedź jako JSON
            } else {
                throw new Error("Błąd podczas pobierania danych");
            }
        })
        .then(json => {
            console.log(json);
            document.getElementById("out").innerText = ""; // Wyczyść zawartość
            json.forEach(item => {
                let div = document.createElement("div");
                div.innerText = item[1]; // Zakładamy, że item[1] to imię
                document.getElementById("out").appendChild(div);
            });
        })
        .catch(error => {
            console.error("Błąd:", error);
        });
}