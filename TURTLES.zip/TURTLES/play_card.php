<?php
require 'db.php';
require 'deck_manager.php';
session_start();

$data = json_decode(file_get_contents('php://input'), true);

$room_id = $data['roomId'];
$player_id = $data['playerId'];
$card_id = $data['id'];
$card_value = $data['value'];
$color = $data['color']; //blue




$stmt = $conn->prepare("SELECT game_state FROM rooms WHERE id = ?");
$stmt->bind_param('i', $room_id);
$stmt->execute();
$result = $stmt->get_result();
$game_state = $result->num_rows > 0 ? json_decode($result->fetch_assoc()['game_state'], true) : [];



//NOWA POZYCJA

if (empty($game_state['positions'])) {
    $game_state['positions'] = [];
}


$found_turtle = false;
$updated_turtles = [];
$new_field = 0;


foreach ($game_state['positions'] as &$pos) {

    //CZY KOLOR KARTY JEST ZGODNY Z KOLOREM ZOLWIA NA POZYCJI
    if ($pos['color'] === $color ) {
        
        $new_field = min(10, $pos['field'] + $card_value); 
        $pos['field'] = $new_field;
        $found_turtle = true;
        
        break;
        
    }
    $updated_turtles = $pos;
}
unset($pos);

if(!$found_turtle){
    echo json_encode([
        'success' => false,
        "error" => 'nie ma zolwia w kolorze tej karty'
    ]);
    exit;
}


// USUNIECIE KARTY
$deckManager = new DeckManager($conn);
$card_removed = $deckManager->removeCardFromPlayer($player_id, $card_id);

if (!$card_removed) {
    echo json_encode([
        'success' => false,
        "error" => 'Nie znaleziono karty do usunięcia'
    ]);
    exit;
}

$deckManager -> addCardToPlayer($player_id, $room_id);



$parsedGameState = json_encode($game_state);
//NOWY STAN
$stmt = $conn->prepare("UPDATE rooms SET game_state = ? WHERE id = ?");
$stmt->bind_param('si', $parsedGameState, $room_id);
$stmt->execute();



//WYSYLAM DANE DO FETCHA
echo json_encode([
    'success' => true,
    'newPosition' => $new_field,
    'gameState' => $game_state,
    'color' => $color,
    'updatedTurtles' => $updated_turtles
]);
?>