<?php
session_start();
print_r($_SESSION);
// print_r($_SESSION['user_id']);
// print_r($_SESSION['room_id']);
// print_r($_SESSION['color']);